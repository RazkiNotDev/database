#==================================#
#Hijacked by anonymous
#==================================#

DEVS = [7637706224]

DEVICE_MODEL = "Razki UserBot"

API_ID = 20141708

API_HASH = "f09a7bdedc2090bfaf9693ea7dece138"

BOT_TOKEN = "8465693726:AAGR1gVGoT2htkVfTl2tgnVbhFBV__lKOCQ"

OWNER_ID = 7637706224

DUMP_LOGS = -1001912692470

USER_ID = 7637706224

LOGS_MAKER_UBOT = -1002546980248

SUPPORT_GROUP = --1002546980248

BLACKLIST_CHAT = [
    -1001473548283,-1001853283409,-1001704645461
    ]

RMBG_API = "3hYYMrCnpDQmAmE81u9aQAz2"

COMMAND = ". ! ? : ;"
PREFIX = COMMAND.split()

MONGO_URL = "mongodb+srv://reon:reon@cluster0.h52cpph.mongodb.net/?retryWrites=true&w=majority"